import numpy as np
import cv2
import matplotlib.pyplot as plt
from code.recover_homographies import computeH
from code.warp_image import warpImageBilinear
import json

# helper fn to make alpha mask
def get_alpha_mask(image):
    # 1 at center o img, fade to zero towards edges
    h = image.shape[0]
    w = image.shape[1]
    x, y = np.mgrid[0:h, 0:w] # coord grid for mask

    # now need to calc distance from each pixel to nearest edge for mask val
    dist_l = x
    dist_r = w - x - 1
    dist_u = y 
    dist_d = h - y - 1

    dist_to_closest_edge = np.minimum(np.minimum(dist_l, dist_r), np.minimum(dist_u, dist_d))
    alpha_mask = dist_to_closest_edge / dist_to_closest_edge.max() # normalize so largest value is 1 and smallest is 0
    alpha_mask_3_channel = np.dstack([alpha_mask]*3)
    return alpha_mask_3_channel

def get_mosaic_bounds(img1, img2, H):
    # project corners of both imgs and return bounding box for mosaic (global mosaic canvas, not warping one img onto the next)
    # warp img2 to img1 frame
    h1 = img1.shape[0]
    h2 = img2.shape[0]
    w1 = img1.shape[1]
    w2 = img2.shape[1]

    img1_corners = np.array([[0,0,1], [w1,0,1], [w1,h1,1], [0, h1, 1]], dtype=np.float64).T
    img2_corners = np.array([[0,0,1], [w2,0,1], [w2,h2,1], [0, h2, 1]], dtype=np.float64).T

    # need to warp the second img corners to align with first img coord system
    img2_corners_warped = H @ img2_corners
    img2_corners_warped /= img2_corners_warped[2] # normalize sp that last elem is still 1

    # combine da corners
    x = np.hstack([img1_corners[0], img2_corners_warped[0]])
    y = np.hstack([img1_corners[1], img2_corners_warped[1]])

    return int(np.floor(x.min())), int(np.ceil(x.max())), int(np.floor(y.min())), int(np.ceil(y.max()))

# # blend second img onto first img to make a mosaicc
# def stitch_and_blend(img1, img2, H):
#     min_x, max_x, min_y, max_y = get_mosaic_bounds(img1, img2, H)
#     out_w, out_h = max_x - min_x, max_y - min_y

#     # need to translate - minx, - min y so centered at 0 (see dic wksht)
#     translate = np.array([[1,0,-min_x], [0, 1, -min_y], [0, 0 , 1]], dtype=np.float64) 

#     H1 = translate
#     H2 = translate @ H

#     img1_warped = warpImageBilinear(img1, H1, out_w, out_h)
#     img2_warped = warpImageBilinear(img2, H2, out_w, out_h)

#     h_min = min(img1_warped.shape[0], img2_warped.shape[0])
#     w_min = min(img1_warped.shape[1], img2_warped.shape[1])
#     img1_warped = img1_warped[:h_min, :w_min]
#     img2_warped = img2_warped[:h_min, :w_min]


#     # get alpha masks
#     alpha1 = get_alpha_mask(img1_warped)
#     alpha2 = get_alpha_mask(img2_warped)

#     # weighted blending
#     mosaic = (img1_warped.astype(np.float32) * alpha1 + img2_warped.astype(np.float32) * alpha2) / (alpha1 + alpha2 + 1e-6) # debug for zerodiv error
#     return np.clip(mosaic, 0, 255).astype(np.uint8)

## ahhhhhh need to restart this is so confusing


def stitch_and_blend(img1, img2, H):
    # Blend img2 onto img1 using homography H (img2 → img1).
    #ensure both are placed in the same translated mosaic coordinate frame.

    # compute mosaic bounds (canvas limits)
    min_x, max_x, min_y, max_y = get_mosaic_bounds(img1, img2, H)
    out_w, out_h = max_x - min_x, max_y - min_y

    # build translation so everything fits into positive coordinates
    translate = np.array([[1, 0, -min_x],
                          [0, 1, -min_y],
                          [0, 0, 1]], dtype=np.float64)

    # build full homographies for each image (into same global mosaic frame)
    H1 = translate                       # j translation for img1
    H2 = translate @ H                   # translation + homog for img2

    # warp both images into this common framee
    img1_warped = warpImageBilinear(img1, H1, out_w, out_h)
    img2_warped = warpImageBilinear(img2, H2, out_w, out_h)

    mask1 = (img1_warped.sum(axis=2) > 0).astype(np.float32)[..., None]
    mask2 = (img2_warped.sum(axis=2) > 0).astype(np.float32)[..., None]
    overlap = (mask1 * mask2)
    only1 = mask1 * (1 - mask2)
    only2 = mask2 * (1 - mask1)

    # alpha masks
    alpha1 = get_alpha_mask(img1_warped)
    alpha2 = get_alpha_mask(img2_warped)

    # alpha1 = np.where(overlap, 0.5, 1.0)
    #alpha2 = np.where(overlap, 0.5, 1.0)
    mosaic = np.zeros_like(img1_warped, dtype=np.float32)
    mosaic += img1_warped * only1
    mosaic += img2_warped * only2
    mosaic += ((img1_warped*alpha1 + img2_warped*alpha2) / (alpha1 + alpha2 + 1e-6)) *  overlap

    # overlap = (alpha1 > 0) & (alpha2 > 0)
    # mosaic = img1_warped.copy().astype(np.float32)

    # # weighted average blend (DEBUG must avoid division by zero by adding small epsilin to denom)
 
    # mosaic[overlap] = (img1_warped[overlap].astype(np.float32) * alpha1[overlap] +
    #           img2_warped[overlap].astype(np.float32) * alpha2[overlap]) / (alpha1[overlap] + alpha2[overlap]+ 1e-6)
    
    # only_img2 = (alpha2 > 0) & (alpha1 == 0)
    # mosaic[only_img2] = img2_warped[only_img2]

    # numer = img1_warped * alpha1 + img2_warped * alpha2
    # denom = alpha1 + alpha2
    # mosaic= np.divide(numer, denom, out=numer, where=denom>0)


    

    return np.clip(mosaic, 0, 255).astype(np.uint8)


if __name__ == "__main__":
    img_pair_name = "A"  # A, B, or C

    img1 = cv2.cvtColor(cv2.imread(f"./data/{img_pair_name}1.jpg"), cv2.COLOR_BGR2RGB)
    img2 = cv2.cvtColor(cv2.imread(f"./data/{img_pair_name}2.jpg"), cv2.COLOR_BGR2RGB)
   
    with open(f"./data/{img_pair_name}_correspondences.json", "r") as f:
        correspondences = json.load(f)
    img1_pts, img2_pts = np.array(correspondences["im1Points"]), np.array(correspondences["im2Points"])

    H = computeH(img2_pts, img1_pts)


    mosaic = stitch_and_blend(img1, img2, H)

    # visualize mosaic
    plt.figure(figsize=(10, 8))
    plt.imshow(mosaic)
    plt.title(f"Final Mosaic ({img_pair_name})")
    plt.axis("off")
    plt.show()

    # plot correspondences ---
    min_x, max_x, min_y, max_y = get_mosaic_bounds(img1, img2, H)
    translate = np.array([[1, 0, -min_x],
                          [0, 1, -min_y],
                          [0, 0, 1]], dtype=np.float64)
    H2 = translate @ H

    # transform correspondence points
    img2_pts_h = np.hstack([img2_pts, np.ones((len(img2_pts), 1))])
    warped_pts = (H2 @ img2_pts_h.T)
    warped_pts /= warped_pts[2]
    warped_pts = warped_pts[:2].T
    img1_pts_mosaic = img1_pts + np.array([-min_x, -min_y])

    plt.figure(figsize=(10, 8))
    plt.imshow(mosaic)
    plt.scatter(img1_pts_mosaic[:, 0], img1_pts_mosaic[:, 1], color='red', s=30, label='img1_pts')
    plt.scatter(warped_pts[:, 0], warped_pts[:, 1], color='blue', s=30, label='img2 warped')
    plt.legend()
    plt.title("Correspondence alignment on mosaic canvas")
    plt.show()