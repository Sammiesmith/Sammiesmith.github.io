# CS180 Project 3A — Image Mosaicing  
**Author:** Sammie Smith (Fall 2025)  
**Course:** UC Berkeley CS180 – Computer Vision  

---

## Overview

- **Part A2 – Recover Homographies:**  
  Solves the linear system `Ah = b` using Ordinary Least Squares to recover a 3×3 homography matrix for each image pair.  
  📄 [View matrices & vectors](https://docs.google.com/spreadsheets/d/1OH73EVQGJ-F50C0mYkzBH_QPbGQzImOIOkiOC_RHJYE/edit?usp=sharing)

- **Part A3 – Warp Images:**  
  Applies inverse mapping to project images through the recovered homography.  
  Implements both **Nearest Neighbor** (fast) and **Bilinear** (smooth) interpolation.

- **Part A4 – Blend Mosaics:**  
  Warps both images into a shared coordinate frame and merges them with **alpha blending**, weighting image centers more strongly and fading edges for natural transitions.

---

##  Files

```
3/
├── code/
│   ├── recover_homographies.py   # builds A,b and solves Ah=b
│   ├── warp_image.py             # inverse mapping + interpolation
│   ├── make_mosaic.py            # warping + alpha blending
│   ├── plot_correspondences.py   # visualizes matched points
│   └── __init__.py
├── data/                         # input images + final mosaics
├── index.html                    # full project write-up
└── README.md
```

---

##  Example Results

| Mosaic | Scene | Preview |
|--------|--------|----------|
| A | Campanile at Sunset | ![A](./data/A_mosaic.jpeg) |
| B | Southside at Sunset | ![B](./data/B_mosaic.jpeg) |
| C | View from Grimes | ![C](./data/C_mosaic.jpeg) |

---

**Run:**  
```bash
python code/make_mosaic.py
```
Edit `img_pair_name` ("A", "B", or "C") to generate each mosaic.  

For detailed explanations and results, open **[`index.html`](./index.html)** in your browser.

**GPT USE**
I used ChatGPT5 to
-  generate plot_correspondences.py. This file plots precomputed correspondences into the input images for debugging
- generate matplotlib plots for visualizing my results
- generate index.html based off of a google doc i typed up of my results
- generate this README
